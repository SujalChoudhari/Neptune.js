import './style.css'
import * as npt from '@neptune-js/neptune'

class Game extends npt.Application {
  constructor() {
      super();
  }
  init() {
      super.init();
      this.background = new npt.Rect({
          app:this,
          pos: new npt.Vector2(0, 0),
          w: this.width,
          h: this.height,
          color: npt.Color.black
      });
      this.text = new npt.Text({
          app: this,
          parent: this.background, // property of an entity
          pos: new npt.Vector2(200,200),
          text: "Hello World I am Playing Game",
          font: "30px Roboto", // all fonts which are supported by html5 canvas can be used here
          color: npt.Color.white,
          align: "center" // this is text align (similar to the html5 canvas) https://www.w3schools.com/tags/canvas_textalign.asp
      }); 
      this.text.align("center");
      this.text.align('middle');
  }
}
new Game();